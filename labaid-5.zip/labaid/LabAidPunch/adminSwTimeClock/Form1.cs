﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace adminSwTimeClock
{
    public partial class FormAdminLogin : Form
    {
        public FormAdminLogin()
        {
            InitializeComponent();
            panelAHUB.Visible = false;
            panelEditable.Visible = false;
            panelLogin.Visible = true;
            panelWorkerPun.Visible = false;
        }

        private void buttonHome_Click(object sender, EventArgs e)
        {
            panelWorkerPun.Visible = false;
            panelEditable.Visible = false;
            panelLogin.Visible = true;
            panelAHUB.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panelAHUB.Visible = false;
            panelEditable.Visible = false;
            panelLogin.Visible = false;
            panelWorkerPun.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panelAHUB.Visible = true;
            panelEditable.Visible = false;
            panelLogin.Visible = false;
            panelWorkerPun.Visible = false;
        }

        private void buttonEditableDisplay_Click(object sender, EventArgs e)
        {
            panelAHUB.Visible = false;
            panelEditable.Visible = true;
            panelLogin.Visible = false;
            panelWorkerPun.Visible = false;
        }

        private void buttonGoHomeRO_Click(object sender, EventArgs e)
        {
            panelAHUB.Visible = true;
            panelEditable.Visible = false;
            panelLogin.Visible = false;
            panelWorkerPun.Visible = false;
        }

        private void buttonAdminLogin_Click(object sender, EventArgs e)
        {
            if (textBoxApass.Text == "")
            {
                labelERR.Text = ("Please enter a password");
                labelERR.ForeColor = System.Drawing.Color.Red;
            }
            else if (textBoxaUser.Text == "")
            {
                labelERR.Text = ("Please enter a Username");
                labelERR.ForeColor = Color.Red;
            }
            else
            {
                textBoxaUser.Text = String.Empty;
                textBoxApass.Text = String.Empty;
                panelAHUB.Visible = true;
                panelEditable.Visible = false;
                panelLogin.Visible = false;
                panelWorkerPun.Visible = false;
            }

        }

        private void FormAdminLogin_Load(object sender, EventArgs e)
        {

        }
    }
}
