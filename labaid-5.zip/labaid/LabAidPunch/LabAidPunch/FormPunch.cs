﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabAidPunch
{
    public partial class FormPunch : Form
    {
       
        

        public FormPunch()
        {

            InitializeComponent();
            buttonIn.FlatAppearance.BorderSize = 0;
            panelLogin.Visible = false;
            panelSuccess.Visible = false;
            panelHome.Visible = true;
            this.ActiveControl = textBoxSwipe;
        }

       private bool returnSwipe()
        {
            
            DateTime swipeTime = DateTime.Now;
            var time = swipeTime.TimeOfDay;

            if (textBoxSwipe.Text != "")
            {
                labelhomeP.Text = ("Successful Punch at: " + swipeTime);
                this.ActiveControl = textBoxSwipe;
                textBoxSwipe.Text = String.Empty;
                return true;
            }
            else
            {
                labelhomeP.Text = ("Unsuccessful punch. Try again or do a manual punch.");
                this.ActiveControl = textBoxSwipe;
                return false;
            }
            
        }
        private void button1_Click(object sender, EventArgs e)
        {
           

            int studentID;
            //bool goodPunch = false;

            //validation to check the user actually input something
            if (textBoxPassword.Text == "" && textBoxID.Text == "")
            {
                labelSuccess.Text = ("Please enter something");
                labelSuccess.ForeColor = System.Drawing.Color.Red;
            }
            else if (textBoxID.Text == "")
            {
                labelSuccess.Text = ("Enter a Student #!");
                labelSuccess.ForeColor = System.Drawing.Color.Red;
                textBoxPassword.Text = String.Empty;
            }
            else if (textBoxPassword.Text == "")
            {
                labelSuccess.Text = ("Enter a Password!");
                labelSuccess.ForeColor = System.Drawing.Color.Red;
                textBoxID.Text = String.Empty;
            }
            //check that only an integer can be input into the textbox
            else if (!int.TryParse(textBoxID.Text, out studentID))
            {
                labelSuccess.Text = ("Only enter numbers!");
                labelSuccess.ForeColor = System.Drawing.Color.Red;
                textBoxPassword.Text = String.Empty;
                textBoxID.Text = String.Empty;
            }

            //check that combobox has a selected index
            else if (comboLabs.SelectedIndex < 0)
            {
                labelSuccess.Text = ("Select a lab");
                labelSuccess.ForeColor = System.Drawing.Color.Red;
            }
            else
            {//if everything passes, notify good punch
                panelSuccess.Visible = true;
                labelSuccess.Text = String.Empty;
                labelSuccess.ForeColor = System.Drawing.Color.MidnightBlue;
                textBoxPassword.Text = String.Empty;
                textBoxID.Text = String.Empty;
                comboLabs.Text = String.Empty;
                panelLogin.Visible = false;
                //goodPunch = true;
            }



        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.ActiveControl = textBoxSwipe;
        }

        private void comboLabs_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
           

            int studentID;

            //validation to check the user actually input something
            if (textBoxPassword.Text == "" && textBoxID.Text == "")
            {
                labelSuccess.Text = ("Please enter something");
                labelSuccess.ForeColor = System.Drawing.Color.Red;
            }
            else if (textBoxID.Text == "")
            {
                labelSuccess.Text = ("Enter a Student #!");
                labelSuccess.ForeColor = System.Drawing.Color.Red;
                textBoxPassword.Text = String.Empty;
            }
            else if (textBoxPassword.Text == "")
            {
                labelSuccess.Text = ("Enter a Password!");
                labelSuccess.ForeColor = System.Drawing.Color.Red;
                textBoxID.Text = String.Empty;
            }
            //check that only an integer can be input into the textbox
            else if (!int.TryParse(textBoxID.Text, out studentID))
            {
                labelSuccess.Text = ("Only enter numbers!");
                labelSuccess.ForeColor = System.Drawing.Color.Red;
                textBoxPassword.Text = String.Empty;
                textBoxID.Text = String.Empty;
            }
            else if (studentID < 6)
            {
                labelSuccess.Text = ("Please enter 6 digits");
            }

            //check that combobox has a selected index
            else if (comboLabs.SelectedIndex < 0)
            {
                labelSuccess.Text = ("Select a lab");
                labelSuccess.ForeColor = System.Drawing.Color.Red;
            }
            else
            {//if everything passes, notify good punch
                labelSuccess.Text = ("Punched out!");
                labelSuccess.ForeColor = System.Drawing.Color.MidnightBlue;
                textBoxPassword.Text = String.Empty;
                textBoxID.Text = String.Empty;
                comboLabs.Text = String.Empty;
                panelLogin.Visible = false;
                panelSuccess.Visible = true;
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            panelLogin.Visible = false;
            panelSuccess.Visible = false;
            panelHome.Visible = true;
            
        }

        

        private void HomeButton_Click(object sender, EventArgs e)
        {
            labelhomeP.Text = "Swipe your ID for your punch.If the punch is unsuccessful please use the menu on the left to login!";
            panelHome.Visible = true;
            panelLogin.Visible = false;
            panelSuccess.Visible = false;
            
        }

        private void buttonStudent_Click(object sender, EventArgs e)
        {
            panelLogin.Visible = true;
            panelHome.Visible = false;
            panelSuccess.Visible = false;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void labelAdminSuccess_Click(object sender, EventArgs e)
        {

        }

       
        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBoxSwipe_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonPunch_Click(object sender, EventArgs e)
        {
            returnSwipe();

         
        }

        private void labelCurrentTime_Click(object sender, EventArgs e)
        {

        }
    }
}
