﻿namespace adminSwTimeClock
{
    partial class FormAdminLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAdminLogin));
            this.labelSideNav = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelLogin = new System.Windows.Forms.Panel();
            this.labelERR = new System.Windows.Forms.Label();
            this.buttonAdminLogin = new System.Windows.Forms.Button();
            this.textBoxApass = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxaUser = new System.Windows.Forms.TextBox();
            this.labelAdminUser = new System.Windows.Forms.Label();
            this.labelAdminInfo = new System.Windows.Forms.Label();
            this.panelAHUB = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.labelUIA = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonEditableDisplay = new System.Windows.Forms.Button();
            this.buttonShowWorkPunches = new System.Windows.Forms.Button();
            this.labelAHub = new System.Windows.Forms.Label();
            this.buttonHome = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.panelWorkerPun = new System.Windows.Forms.Panel();
            this.buttonGoHomeRO = new System.Windows.Forms.Button();
            this.dataGridViewRO = new System.Windows.Forms.DataGridView();
            this.Studentid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Punchin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PunchOut = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lab = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.labelWPreportTitle = new System.Windows.Forms.Label();
            this.panelEditable = new System.Windows.Forms.Panel();
            this.buttonGoHomeE = new System.Windows.Forms.Button();
            this.dataGridViewEdit = new System.Windows.Forms.DataGridView();
            this.dataGridViewEditable = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.labelEditPunchesH = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelLogin.SuspendLayout();
            this.panelAHUB.SuspendLayout();
            this.panelWorkerPun.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRO)).BeginInit();
            this.panelEditable.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEdit)).BeginInit();
            this.SuspendLayout();
            // 
            // labelSideNav
            // 
            this.labelSideNav.BackColor = System.Drawing.Color.LightBlue;
            this.labelSideNav.Location = new System.Drawing.Point(-2, -1);
            this.labelSideNav.Name = "labelSideNav";
            this.labelSideNav.Size = new System.Drawing.Size(248, 504);
            this.labelSideNav.TabIndex = 16;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.LightBlue;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(29, 33);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(195, 108);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 17;
            this.pictureBox1.TabStop = false;
            // 
            // panelLogin
            // 
            this.panelLogin.BackColor = System.Drawing.Color.Transparent;
            this.panelLogin.Controls.Add(this.labelERR);
            this.panelLogin.Controls.Add(this.buttonAdminLogin);
            this.panelLogin.Controls.Add(this.textBoxApass);
            this.panelLogin.Controls.Add(this.label1);
            this.panelLogin.Controls.Add(this.textBoxaUser);
            this.panelLogin.Controls.Add(this.labelAdminUser);
            this.panelLogin.Location = new System.Drawing.Point(263, 13);
            this.panelLogin.Name = "panelLogin";
            this.panelLogin.Size = new System.Drawing.Size(750, 472);
            this.panelLogin.TabIndex = 19;
            // 
            // labelERR
            // 
            this.labelERR.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelERR.Location = new System.Drawing.Point(205, 338);
            this.labelERR.Name = "labelERR";
            this.labelERR.Size = new System.Drawing.Size(360, 112);
            this.labelERR.TabIndex = 6;
            this.labelERR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // buttonAdminLogin
            // 
            this.buttonAdminLogin.BackColor = System.Drawing.Color.RoyalBlue;
            this.buttonAdminLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAdminLogin.ForeColor = System.Drawing.Color.White;
            this.buttonAdminLogin.Location = new System.Drawing.Point(416, 239);
            this.buttonAdminLogin.Name = "buttonAdminLogin";
            this.buttonAdminLogin.Size = new System.Drawing.Size(154, 78);
            this.buttonAdminLogin.TabIndex = 5;
            this.buttonAdminLogin.Text = "Login";
            this.buttonAdminLogin.UseVisualStyleBackColor = false;
            this.buttonAdminLogin.Click += new System.EventHandler(this.buttonAdminLogin_Click);
            // 
            // textBoxApass
            // 
            this.textBoxApass.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxApass.Location = new System.Drawing.Point(416, 152);
            this.textBoxApass.Name = "textBoxApass";
            this.textBoxApass.PasswordChar = '*';
            this.textBoxApass.Size = new System.Drawing.Size(251, 44);
            this.textBoxApass.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(193, 152);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(183, 42);
            this.label1.TabIndex = 3;
            this.label1.Text = "Password";
            // 
            // textBoxaUser
            // 
            this.textBoxaUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxaUser.Location = new System.Drawing.Point(416, 92);
            this.textBoxaUser.Name = "textBoxaUser";
            this.textBoxaUser.Size = new System.Drawing.Size(251, 44);
            this.textBoxaUser.TabIndex = 2;
            // 
            // labelAdminUser
            // 
            this.labelAdminUser.AutoSize = true;
            this.labelAdminUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAdminUser.ForeColor = System.Drawing.Color.White;
            this.labelAdminUser.Location = new System.Drawing.Point(186, 95);
            this.labelAdminUser.Name = "labelAdminUser";
            this.labelAdminUser.Size = new System.Drawing.Size(190, 42);
            this.labelAdminUser.TabIndex = 0;
            this.labelAdminUser.Text = "Username";
            // 
            // labelAdminInfo
            // 
            this.labelAdminInfo.BackColor = System.Drawing.Color.LightBlue;
            this.labelAdminInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAdminInfo.ForeColor = System.Drawing.Color.RoyalBlue;
            this.labelAdminInfo.Location = new System.Drawing.Point(1, 189);
            this.labelAdminInfo.Name = "labelAdminInfo";
            this.labelAdminInfo.Size = new System.Drawing.Size(244, 228);
            this.labelAdminInfo.TabIndex = 20;
            this.labelAdminInfo.Text = "Admin Time Clock Management";
            this.labelAdminInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelAHUB
            // 
            this.panelAHUB.BackColor = System.Drawing.Color.Transparent;
            this.panelAHUB.Controls.Add(this.label6);
            this.panelAHUB.Controls.Add(this.labelUIA);
            this.panelAHUB.Controls.Add(this.label4);
            this.panelAHUB.Controls.Add(this.label3);
            this.panelAHUB.Controls.Add(this.buttonEditableDisplay);
            this.panelAHUB.Controls.Add(this.buttonShowWorkPunches);
            this.panelAHUB.Controls.Add(this.labelAHub);
            this.panelAHUB.Controls.Add(this.buttonHome);
            this.panelAHUB.Controls.Add(this.label5);
            this.panelAHUB.Location = new System.Drawing.Point(263, 12);
            this.panelAHUB.Name = "panelAHUB";
            this.panelAHUB.Size = new System.Drawing.Size(750, 472);
            this.panelAHUB.TabIndex = 21;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.LightBlue;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label6.Location = new System.Drawing.Point(3, 280);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(242, 189);
            this.label6.TabIndex = 24;
            this.label6.Text = "Editable will allow you to correct missed punches, or correct labs.";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelUIA
            // 
            this.labelUIA.BackColor = System.Drawing.Color.LightBlue;
            this.labelUIA.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUIA.ForeColor = System.Drawing.Color.RoyalBlue;
            this.labelUIA.Location = new System.Drawing.Point(3, 75);
            this.labelUIA.Name = "labelUIA";
            this.labelUIA.Size = new System.Drawing.Size(242, 189);
            this.labelUIA.TabIndex = 23;
            this.labelUIA.Text = "Report for Worker Punches will display a printable report of the workers punches," +
    " lab, and date.";
            this.labelUIA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(324, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 25);
            this.label4.TabIndex = 8;
            this.label4.Text = "Reports";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(324, 240);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 25);
            this.label3.TabIndex = 7;
            this.label3.Text = "Editable";
            // 
            // buttonEditableDisplay
            // 
            this.buttonEditableDisplay.BackColor = System.Drawing.Color.RoyalBlue;
            this.buttonEditableDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEditableDisplay.ForeColor = System.Drawing.Color.White;
            this.buttonEditableDisplay.Location = new System.Drawing.Point(273, 268);
            this.buttonEditableDisplay.Name = "buttonEditableDisplay";
            this.buttonEditableDisplay.Size = new System.Drawing.Size(195, 51);
            this.buttonEditableDisplay.TabIndex = 4;
            this.buttonEditableDisplay.Text = "Edit Punches";
            this.buttonEditableDisplay.UseVisualStyleBackColor = false;
            this.buttonEditableDisplay.Click += new System.EventHandler(this.buttonEditableDisplay_Click);
            // 
            // buttonShowWorkPunches
            // 
            this.buttonShowWorkPunches.BackColor = System.Drawing.Color.RoyalBlue;
            this.buttonShowWorkPunches.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonShowWorkPunches.ForeColor = System.Drawing.Color.White;
            this.buttonShowWorkPunches.Location = new System.Drawing.Point(273, 75);
            this.buttonShowWorkPunches.Name = "buttonShowWorkPunches";
            this.buttonShowWorkPunches.Size = new System.Drawing.Size(195, 51);
            this.buttonShowWorkPunches.TabIndex = 3;
            this.buttonShowWorkPunches.Text = "Worker Punches";
            this.buttonShowWorkPunches.UseVisualStyleBackColor = false;
            this.buttonShowWorkPunches.Click += new System.EventHandler(this.button1_Click);
            // 
            // labelAHub
            // 
            this.labelAHub.AutoSize = true;
            this.labelAHub.BackColor = System.Drawing.Color.LightBlue;
            this.labelAHub.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAHub.ForeColor = System.Drawing.Color.RoyalBlue;
            this.labelAHub.Location = new System.Drawing.Point(33, 21);
            this.labelAHub.Name = "labelAHub";
            this.labelAHub.Size = new System.Drawing.Size(177, 37);
            this.labelAHub.TabIndex = 1;
            this.labelAHub.Text = "Admin Hub";
            // 
            // buttonHome
            // 
            this.buttonHome.BackColor = System.Drawing.Color.RoyalBlue;
            this.buttonHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonHome.ForeColor = System.Drawing.Color.White;
            this.buttonHome.Location = new System.Drawing.Point(308, 421);
            this.buttonHome.Name = "buttonHome";
            this.buttonHome.Size = new System.Drawing.Size(129, 51);
            this.buttonHome.TabIndex = 0;
            this.buttonHome.Text = "Home";
            this.buttonHome.UseVisualStyleBackColor = false;
            this.buttonHome.Click += new System.EventHandler(this.buttonHome_Click);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.LightBlue;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Location = new System.Drawing.Point(0, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(251, 472);
            this.label5.TabIndex = 22;
            // 
            // panelWorkerPun
            // 
            this.panelWorkerPun.BackColor = System.Drawing.Color.Transparent;
            this.panelWorkerPun.Controls.Add(this.buttonGoHomeRO);
            this.panelWorkerPun.Controls.Add(this.dataGridViewRO);
            this.panelWorkerPun.Controls.Add(this.labelWPreportTitle);
            this.panelWorkerPun.Location = new System.Drawing.Point(263, 11);
            this.panelWorkerPun.Name = "panelWorkerPun";
            this.panelWorkerPun.Size = new System.Drawing.Size(750, 472);
            this.panelWorkerPun.TabIndex = 22;
            // 
            // buttonGoHomeRO
            // 
            this.buttonGoHomeRO.BackColor = System.Drawing.Color.RoyalBlue;
            this.buttonGoHomeRO.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonGoHomeRO.ForeColor = System.Drawing.Color.White;
            this.buttonGoHomeRO.Location = new System.Drawing.Point(7, 374);
            this.buttonGoHomeRO.Name = "buttonGoHomeRO";
            this.buttonGoHomeRO.Size = new System.Drawing.Size(154, 78);
            this.buttonGoHomeRO.TabIndex = 6;
            this.buttonGoHomeRO.Text = "Back";
            this.buttonGoHomeRO.UseVisualStyleBackColor = false;
            this.buttonGoHomeRO.Click += new System.EventHandler(this.buttonGoHomeRO_Click);
            // 
            // dataGridViewRO
            // 
            this.dataGridViewRO.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewRO.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Studentid,
            this.firstName,
            this.lastName,
            this.Date,
            this.Punchin,
            this.PunchOut,
            this.lab});
            this.dataGridViewRO.Location = new System.Drawing.Point(3, 55);
            this.dataGridViewRO.Name = "dataGridViewRO";
            this.dataGridViewRO.Size = new System.Drawing.Size(746, 313);
            this.dataGridViewRO.TabIndex = 3;
            // 
            // Studentid
            // 
            this.Studentid.HeaderText = "ID#";
            this.Studentid.Name = "Studentid";
            this.Studentid.ReadOnly = true;
            // 
            // firstName
            // 
            this.firstName.HeaderText = "First Name";
            this.firstName.Name = "firstName";
            this.firstName.ReadOnly = true;
            // 
            // lastName
            // 
            this.lastName.HeaderText = "Last Name";
            this.lastName.Name = "lastName";
            this.lastName.ReadOnly = true;
            // 
            // Date
            // 
            this.Date.HeaderText = "Date";
            this.Date.Name = "Date";
            this.Date.ReadOnly = true;
            // 
            // Punchin
            // 
            this.Punchin.HeaderText = "Punch In";
            this.Punchin.Name = "Punchin";
            // 
            // PunchOut
            // 
            this.PunchOut.HeaderText = "Punch Out";
            this.PunchOut.Name = "PunchOut";
            // 
            // lab
            // 
            this.lab.HeaderText = "Lab";
            this.lab.Name = "lab";
            // 
            // labelWPreportTitle
            // 
            this.labelWPreportTitle.BackColor = System.Drawing.Color.LightBlue;
            this.labelWPreportTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelWPreportTitle.ForeColor = System.Drawing.Color.RoyalBlue;
            this.labelWPreportTitle.Location = new System.Drawing.Point(3, 0);
            this.labelWPreportTitle.Name = "labelWPreportTitle";
            this.labelWPreportTitle.Size = new System.Drawing.Size(746, 52);
            this.labelWPreportTitle.TabIndex = 2;
            this.labelWPreportTitle.Text = "Student Worker Punches";
            this.labelWPreportTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelEditable
            // 
            this.panelEditable.BackColor = System.Drawing.Color.Transparent;
            this.panelEditable.Controls.Add(this.buttonGoHomeE);
            this.panelEditable.Controls.Add(this.dataGridViewEdit);
            this.panelEditable.Controls.Add(this.labelEditPunchesH);
            this.panelEditable.Location = new System.Drawing.Point(262, 10);
            this.panelEditable.Name = "panelEditable";
            this.panelEditable.Size = new System.Drawing.Size(750, 472);
            this.panelEditable.TabIndex = 23;
            // 
            // buttonGoHomeE
            // 
            this.buttonGoHomeE.BackColor = System.Drawing.Color.RoyalBlue;
            this.buttonGoHomeE.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonGoHomeE.ForeColor = System.Drawing.Color.White;
            this.buttonGoHomeE.Location = new System.Drawing.Point(7, 374);
            this.buttonGoHomeE.Name = "buttonGoHomeE";
            this.buttonGoHomeE.Size = new System.Drawing.Size(154, 78);
            this.buttonGoHomeE.TabIndex = 6;
            this.buttonGoHomeE.Text = "Back";
            this.buttonGoHomeE.UseVisualStyleBackColor = false;
            this.buttonGoHomeE.Click += new System.EventHandler(this.button4_Click);
            // 
            // dataGridViewEdit
            // 
            this.dataGridViewEdit.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewEdit.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewEditable,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.dataGridViewEdit.Location = new System.Drawing.Point(3, 55);
            this.dataGridViewEdit.Name = "dataGridViewEdit";
            this.dataGridViewEdit.Size = new System.Drawing.Size(744, 313);
            this.dataGridViewEdit.TabIndex = 3;
            // 
            // dataGridViewEditable
            // 
            this.dataGridViewEditable.HeaderText = "ID#";
            this.dataGridViewEditable.Name = "dataGridViewEditable";
            this.dataGridViewEditable.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "First Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Last Name";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "Date";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Punch In";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "Punch Out";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "Lab";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // labelEditPunchesH
            // 
            this.labelEditPunchesH.BackColor = System.Drawing.Color.LightBlue;
            this.labelEditPunchesH.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEditPunchesH.ForeColor = System.Drawing.Color.RoyalBlue;
            this.labelEditPunchesH.Location = new System.Drawing.Point(0, 0);
            this.labelEditPunchesH.Name = "labelEditPunchesH";
            this.labelEditPunchesH.Size = new System.Drawing.Size(747, 52);
            this.labelEditPunchesH.TabIndex = 2;
            this.labelEditPunchesH.Text = "Editable Work Punches";
            this.labelEditPunchesH.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FormAdminLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1022, 493);
            this.Controls.Add(this.panelLogin);
            this.Controls.Add(this.labelAdminInfo);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.labelSideNav);
            this.Controls.Add(this.panelAHUB);
            this.Controls.Add(this.panelWorkerPun);
            this.Controls.Add(this.panelEditable);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormAdminLogin";
            this.Text = "Admin Time Clock Viewer";
            this.Load += new System.EventHandler(this.FormAdminLogin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelLogin.ResumeLayout(false);
            this.panelLogin.PerformLayout();
            this.panelAHUB.ResumeLayout(false);
            this.panelAHUB.PerformLayout();
            this.panelWorkerPun.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRO)).EndInit();
            this.panelEditable.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEdit)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label labelSideNav;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panelLogin;
        private System.Windows.Forms.Label labelERR;
        private System.Windows.Forms.Button buttonAdminLogin;
        private System.Windows.Forms.TextBox textBoxApass;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxaUser;
        private System.Windows.Forms.Label labelAdminUser;
        private System.Windows.Forms.Label labelAdminInfo;
        private System.Windows.Forms.Panel panelAHUB;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label labelUIA;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonEditableDisplay;
        private System.Windows.Forms.Button buttonShowWorkPunches;
        private System.Windows.Forms.Label labelAHub;
        private System.Windows.Forms.Button buttonHome;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panelWorkerPun;
        private System.Windows.Forms.Button buttonGoHomeRO;
        private System.Windows.Forms.DataGridView dataGridViewRO;
        private System.Windows.Forms.DataGridViewTextBoxColumn Studentid;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstName;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Date;
        private System.Windows.Forms.DataGridViewTextBoxColumn Punchin;
        private System.Windows.Forms.DataGridViewTextBoxColumn PunchOut;
        private System.Windows.Forms.DataGridViewTextBoxColumn lab;
        private System.Windows.Forms.Label labelWPreportTitle;
        private System.Windows.Forms.Panel panelEditable;
        private System.Windows.Forms.Button buttonGoHomeE;
        private System.Windows.Forms.DataGridView dataGridViewEdit;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewEditable;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.Label labelEditPunchesH;
    }
}

