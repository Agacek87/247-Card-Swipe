﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabAidPunch
{
    public partial class FormPunch : Form
    {
        public FormPunch()
        {
        // load form and only show the home panel
            InitializeComponent();
            buttonIn.FlatAppearance.BorderSize = 0;
            panelLogin.Visible = false;
            panelSuccess.Visible = false;
            panelHome.Visible = true;
            this.ActiveControl = textBoxSwipe;

            var dateAndTime = DateTime.Now;
            var date = dateAndTime.Date;

            labelDate.Text = date.ToString("MM/dd/yyyy");
        }
       
        private bool returnSwipe()
        {
            
            DateTime swipeTime = DateTime.Now;
            //is they swiped their id
            if (textBoxSwipe.Text != "")
            {
                labelhomeP.Text = ("Successful Punch at: " + swipeTime);
                this.ActiveControl = textBoxSwipe;
                textBoxSwipe.Text = String.Empty;
                labelhomeP.ForeColor = System.Drawing.Color.LightGreen;
                return true;
            }
            //if they didnt swipe their id 
            else
            {
                labelhomeP.Text = ("Unsuccessful punch");
                labelhomeP.ForeColor = System.Drawing.Color.Red;
                this.ActiveControl = textBoxSwipe;
                return false;
            }
            
        }
        private void button1_Click(object sender, EventArgs e)
        {
           

            int studentID;
            //bool goodPunch = false;

            //validation to check the user actually input something
           
             if (textBoxID.Text == "")
            {
                labelSuccess.Text = ("Enter a Student #!");
                labelSuccess.ForeColor = System.Drawing.Color.Red;
               
            }
           
            //check that only an integer can be input into the textbox
            else if (!int.TryParse(textBoxID.Text, out studentID))
            {
                labelSuccess.Text = ("Only enter numbers!");
                labelSuccess.ForeColor = System.Drawing.Color.Red;
                
                textBoxID.Text = String.Empty;
            }

            //check that combobox has a selected index
            else if (comboLabs.SelectedIndex < 0)
            {
                labelSuccess.Text = ("Select a lab");
                labelSuccess.ForeColor = System.Drawing.Color.Red;
            }
            else
            {//if everything passes, notify good punch
                labelhomeP.ForeColor = System.Drawing.Color.White;
                panelSuccess.Visible = true;
                labelSuccess.Text = String.Empty;
                labelSuccess.ForeColor = System.Drawing.Color.MidnightBlue;
                textBoxID.Text = String.Empty;
                comboLabs.Text = String.Empty;
                panelLogin.Visible = false;
                //goodPunch = true;
            }



        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.ActiveControl = textBoxSwipe;
            timer1.Start();
          
        }

        private void comboLabs_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
           

            int studentID;

            //validation to check the user actually input something
            
            if (textBoxID.Text == "")
            {
                labelSuccess.Text = ("Enter a Student #!");
                labelSuccess.ForeColor = System.Drawing.Color.Red;
            }
            //check that only an integer can be input into the textbox
            else if (!int.TryParse(textBoxID.Text, out studentID))
            {
                labelSuccess.Text = ("Only enter numbers!");
                labelSuccess.ForeColor = System.Drawing.Color.Red;
                textBoxID.Text = String.Empty;
            }
            else if (studentID < 6)
            {
                labelSuccess.Text = ("Please enter 6 digits");
            }

            //check that combobox has a selected index
            else if (comboLabs.SelectedIndex < 0)
            {
                labelSuccess.Text = ("Select a lab");
                labelSuccess.ForeColor = System.Drawing.Color.Red;
            }
            else
            {//if everything passes, notify good punch
                labelhomeP.ForeColor = System.Drawing.Color.White;
                labelSuccess.Text = ("Punched out!");
                labelSuccess.ForeColor = System.Drawing.Color.MidnightBlue;
                textBoxID.Text = String.Empty;
                comboLabs.Text = String.Empty;
                panelLogin.Visible = false;
                panelSuccess.Visible = true;
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            panelLogin.Visible = false;
            panelSuccess.Visible = false;
            panelHome.Visible = true;
            this.ActiveControl = textBoxSwipe;

        }

        

        private void HomeButton_Click(object sender, EventArgs e)
        {
            labelhomeP.ForeColor = System.Drawing.Color.White;
            labelhomeP.Text = "Swipe to Clock IN or OUT";
            panelHome.Visible = true;
            panelLogin.Visible = false;
            panelSuccess.Visible = false;
            this.ActiveControl = textBoxSwipe;

        }

        private void buttonStudent_Click(object sender, EventArgs e)
        {
            panelLogin.Visible = true;
            panelHome.Visible = false;
            panelSuccess.Visible = false;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void labelAdminSuccess_Click(object sender, EventArgs e)
        {

        }

       
        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBoxSwipe_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonPunch_Click(object sender, EventArgs e)
        {
            //pull the method to see if they swiped
            returnSwipe();
        }

        private void labelCurrentTime_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            labelCurrentTime.Text = DateTime.Now.ToString("hh:mm:ss tt");
        }

        private void buttonHelp_Click(object sender, EventArgs e)
        {
            MessageBox.Show("To clock in, swipe your student ID and hit 'Punch'. \nWhen you're ready to clock out, simply swipe your ID again, and hit Punch. \nIf you're student ID is not working, hit 'Student Login' to manually punch.");
        }

        private void labelDate_Click(object sender, EventArgs e)
        {

        }

        private void labelhomeP_Click(object sender, EventArgs e)
        {

        }
    }
}
